# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: controls.mjs >> Worker phase negative/positive control hash
- Location: release1-worker-phases\controls.mjs:5:42

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false

Call Log:
- Timeout 10000ms exceeded while waiting on the predicate
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import {readFile} from 'node:fs/promises';
  3  | import {join,resolve} from 'node:path';
  4  | import {observeContext,origin} from './observe-context.mjs';
  5  | for(const mode of ['503','hash','delay'])test('Worker phase negative/positive control '+mode,async({browser},info)=>{
  6  |  const context=await browser.newContext({baseURL:origin});const record=await observeContext(context,info,0,mode);
  7  |  try{
  8  |   const page=await context.newPage();await page.goto('/#Dashboard');await expect(page.getByRole('heading',{name:'Welcome to a better-kept workshop'})).toBeVisible();
  9  |   const path=join(resolve(process.env.PRINTGUARD_FORENSIC_RUN),'events',record.id+'.ndjson');
  10 |   const events=async()=>{try{return(await readFile(path,'utf8')).trim().split('\n').map(line=>JSON.parse(line));}catch{return[];}};
  11 |   if(mode==='delay'){
  12 |    await expect.poll(async()=>(await events()).some(event=>event.event==='claim-end'),{timeout:15000}).toBe(true);
  13 |    await expect.poll(async()=>page.evaluate(()=>!!navigator.serviceWorker.controller),{timeout:5000}).toBe(true);
  14 |    expect((await events()).filter(event=>event.event==='digest').every(event=>event.match)).toBe(true);
  15 |    expect((await events()).some(event=>event.event==='marker-complete')).toBe(true);
  16 |   }else{
> 17 |    await expect.poll(async()=>(await events()).some(event=>event.event==='install-reject'),{timeout:10000}).toBe(true);
     |                                                                                                             ^ Error: expect(received).toBe(expected) // Object.is equality
  18 |    const rows=await events();expect(rows.some(event=>event.event==='marker-complete')).toBe(false);expect(await page.evaluate(()=>!!navigator.serviceWorker.controller)).toBe(false);
  19 |    if(mode==='hash')expect(rows.some(event=>event.event==='digest'&&event.match===false)).toBe(true);
  20 |   }
  21 |   await info.attach('forensic-context',{body:JSON.stringify({context:record.id,mode}),contentType:'application/json'});
  22 |  }finally{await context.close();}
  23 | });
  24 | 
```