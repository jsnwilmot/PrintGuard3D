# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: release.cross.mjs >> D07 notification permission unsupported keeps truthful app-open behavior
- Location: remediation-phase5\native\release.cross.mjs:46:55

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('status')
Expected substring: "not supported"
Error: strict mode violation: getByRole('status') resolved to 2 elements:
    1) <p role="status">Preparing offline access. You can continue workin…</p> aka getByText('Preparing offline access. You')
    2) <div role="status" class="toast">…</div> aka getByText('Browser notifications are not')

Call log:
  - Expect "toContainText" getByRole('status') with timeout 15000ms
  - waiting for getByRole('status')

```

# Page snapshot

```yaml
- generic [ref=f1e2]:
  - link "Skip to content" [ref=f1e3] [cursor=pointer]:
    - /url: "#main-content"
  - generic [ref=f1e4]:
    - complementary [ref=f1e5]:
      - link [ref=f1e6] [cursor=pointer]:
        - /url: "#Dashboard"
        - img "PrintGuard 3D" [ref=f1e7]
      - generic [ref=f1e8]: WORKSPACE
      - navigation "Main navigation" [ref=f1e9]:
        - button "Dashboard" [ref=f1e10] [cursor=pointer]
        - button "My Printers 3" [ref=f1e17] [cursor=pointer]:
          - generic [ref=f1e22]: My Printers
          - generic [ref=f1e23]: "3"
        - button "Maintenance 1" [ref=f1e24] [cursor=pointer]:
          - generic [ref=f1e27]: Maintenance
          - generic [ref=f1e28]: "1"
        - button "Calendar" [ref=f1e29] [cursor=pointer]
        - button "Reports" [ref=f1e42] [cursor=pointer]
        - button "Inventory" [ref=f1e51] [cursor=pointer]
      - generic [ref=f1e58]:
        - generic [ref=f1e59]: RESOURCES
        - button "Help & documentation" [ref=f1e60] [cursor=pointer]
        - button "Settings" [ref=f1e64] [cursor=pointer]
        - generic [ref=f1e68]:
          - generic [ref=f1e69]: BROWSER STORAGE
          - heading "Your data. Your device." [level=3] [ref=f1e71]
          - paragraph [ref=f1e72]: A little backup goes a long way.
          - button "Back up your workshop" [ref=f1e73] [cursor=pointer]
        - generic [ref=f1e77]:
          - generic [ref=f1e78]: r&p
          - generic [ref=f1e79]:
            - text: Crafted with care by
            - strong [ref=f1e80]: Rose & Paw Digital Designs
    - generic [ref=f1e81]:
      - banner [ref=f1e82]:
        - generic [ref=f1e83]:
          - generic [ref=f1e84]: My workspace
          - strong [ref=f1e92]: Settings
        - generic [ref=f1e93]:
          - textbox "Search printers and tasks" [ref=f1e98]:
            - /placeholder: Search your workshop…
          - button "Notifications, 2 unread" [ref=f1e100] [cursor=pointer]
          - button "Workspace settings" [ref=f1e105] [cursor=pointer]: W
      - main [ref=f1e106]:
        - region "Offline access status" [ref=f1e107]:
          - heading "Offline access is not confirmed" [level=2] [ref=f1e108]
          - status [ref=f1e109]: Offline access is not ready. Your workshop remains available while online. Stay online, keep a backup and reconnect/recheck before relying on offline use.
          - button "Recheck offline access" [ref=f1e110] [cursor=pointer]
          - button "Dismiss warning for this session" [ref=f1e111] [cursor=pointer]
        - generic [ref=f1e113]:
          - generic [ref=f1e114]: MAKE IT YOURS
          - heading "Settings" [level=1] [ref=f1e115]
          - paragraph [ref=f1e116]: Your workshop preferences. Your data, in your hands.
        - generic [ref=f1e117]:
          - generic [ref=f1e118]:
            - generic [ref=f1e126]:
              - heading "A safe home for your records" [level=2] [ref=f1e127]
              - paragraph [ref=f1e128]: Back up regularly. Browser storage can be cleared or evicted.
              - paragraph [ref=f1e129]: Full backups contain user-entered notes, photographs and saved decisions. Files are not encrypted by PrintGuard. Protect your copies and test restoration in a separate browser profile. Reports are not full recovery backups.
              - button "Read data handling information" [ref=f1e130] [cursor=pointer]
            - generic [ref=f1e131]:
              - generic [ref=f1e132]:
                - strong [ref=f1e133]: Everything, in one file.
                - paragraph [ref=f1e134]: Printers, recurring rules, service history, readings, inventory, repairs, images, profiles, preferences, and captured overdue observations.
                - generic [ref=f1e135]: "Last backup: Jan 1, 2026"
              - button "Back Up My Data" [ref=f1e136] [cursor=pointer]
            - generic [ref=f1e141]:
              - generic [ref=f1e142]:
                - strong [ref=f1e143]: Import a backup
                - paragraph [ref=f1e144]: Validate and preview before merging or replacing records.
                - paragraph [ref=f1e145]: Recommendation decisions and caveats are included in full backups. Older strict backup readers reject new decision fields. Keep this application version when using these reminders; a database version alone cannot fence an old Dexie runtime.
                - paragraph [ref=f1e146]: "Backup compatibility: schema 1 does not guarantee that older apps can read newer optional fields. Use this version or newer to restore current exports. Older strict readers may reject the entire file; never remove fields to force an import."
              - generic [ref=f1e147] [cursor=pointer]:
                - text: Choose JSON file
                - button "Choose JSON file" [ref=f1e152]
            - generic [ref=f1e159]:
              - strong [ref=f1e160]: Stored on this device, in this browser
              - paragraph [ref=f1e161]: Records do not automatically sync between devices. Clearing browser data may delete them.
              - generic [ref=f1e162]: 0.2 MB in use · 10.0 GB browser quota · Persistence not granted
            - button "Request persistent storage" [ref=f1e163] [cursor=pointer]
          - generic [ref=f1e164]:
            - generic [ref=f1e177]:
              - heading "Designed around you" [level=2] [ref=f1e178]
              - paragraph [ref=f1e179]: A comfortable place to keep things running.
            - generic [ref=f1e180]:
              - generic [ref=f1e181]:
                - strong [ref=f1e182]: Appearance
                - paragraph [ref=f1e183]: A lighter view or a little less glare.
              - generic [ref=f1e184]:
                - button "Light" [ref=f1e185] [cursor=pointer]
                - button "Dark" [pressed] [ref=f1e196] [cursor=pointer]
            - generic [ref=f1e199]:
              - generic [ref=f1e200]:
                - generic [ref=f1e201]: On-time maintenance goal (%)
                - spinbutton "On-time maintenance goal (%)" [ref=f1e202]: "95"
                - generic [ref=f1e203]: An application goal you control, not a manufacturer requirement.
              - generic [ref=f1e204]:
                - generic [ref=f1e205]: Expense currency
                - combobox "Expense currency" [ref=f1e206]:
                  - option "CAD"
                  - option "USD" [selected]
                  - option "EUR"
                  - option "GBP"
                  - option "AUD"
                  - option "NZD"
            - generic [ref=f1e207]:
              - generic [ref=f1e208]:
                - generic [ref=f1e209]: Overdue critical task goal
                - spinbutton "Overdue critical task goal" [ref=f1e210]: "0"
                - generic [ref=f1e211]: User-configurable application goal, not a manufacturer requirement.
              - generic [ref=f1e212]:
                - generic [ref=f1e213]: Recorded missed occurrence goal
                - spinbutton "Recorded missed occurrence goal" [ref=f1e214]: "0"
                - generic [ref=f1e215]: User-configurable application goal, not a manufacturer requirement.
            - generic [ref=f1e216]:
              - checkbox "Show achievements earned from real service history" [checked] [ref=f1e217] [cursor=pointer]
              - text: Show achievements earned from real service history
          - generic [ref=f1e218]:
            - generic [ref=f1e224]:
              - heading "A timely little nudge" [level=2] [ref=f1e225]
              - paragraph [ref=f1e226]: Reminders work while PrintGuard is open.
            - generic [ref=f1e227]:
              - generic [ref=f1e228]: "Approaching maintenance: days before due"
              - 'spinbutton "Approaching maintenance: days before due" [ref=f1e229]': "7"
            - generic [ref=f1e230]:
              - generic [ref=f1e231]:
                - strong [ref=f1e232]: Browser notifications
                - paragraph [ref=f1e233]: Optional, permission-based reminders while the app is open.
              - button "Enable notifications" [active] [ref=f1e234] [cursor=pointer]
            - paragraph [ref=f1e235]: Scheduled notifications are not guaranteed when this application is closed. The notification centre includes due, overdue, low-stock, and backup reminders.
          - generic [ref=f1e236]:
            - generic [ref=f1e242]:
              - heading "Profiles with a paper trail" [level=2] [ref=f1e243]
              - paragraph [ref=f1e244]: PrintGuard 3D is independent and unofficial; no printer manufacturer sponsors, endorses or supports this application. Manufacturer and model names identify equipment only. Brand names belong to their respective owners.
              - paragraph [ref=f1e245]: Independent, versioned maintenance definitions.
            - generic [ref=f1e246]:
              - generic [ref=f1e247]:
                - strong [ref=f1e248]: Custom Custom Resin
                - paragraph [ref=f1e249]: v2.0.0 · 0 procedure(s)
              - generic [ref=f1e250]: Pending Verification
            - generic [ref=f1e252]:
              - generic [ref=f1e253]:
                - strong [ref=f1e254]: FlashForge Creator 5
                - paragraph [ref=f1e255]: v1.0.0 · 1 procedure(s)
              - generic [ref=f1e256]: Documented facts; limited coverage
            - generic [ref=f1e258]:
              - generic [ref=f1e259]:
                - strong [ref=f1e260]: FlashForge Creator 5 Pro
                - paragraph [ref=f1e261]: v1.0.0 · 1 procedure(s)
              - generic [ref=f1e262]: Documented facts; limited coverage
            - generic [ref=f1e264]:
              - generic [ref=f1e265]:
                - strong [ref=f1e266]: "Reviewed library: Creator 5 v1.1.0"
                - paragraph [ref=f1e267]: "Partial overall coverage: all 18 maintenance text articles reviewed; stock Creator 5 excludes unconfirmed filtration/chamber equipment. Eight fixed-interval tasks include the separate 1000-hour user-guide task; eight further procedures need explicit usage-band selection. Condition/corrective references are not scheduled. Indexed videos and band-boundary ambiguities remain unresolved."
              - button "Review Creator 5 v1.1.0" [ref=f1e268] [cursor=pointer]
            - generic [ref=f1e269]:
              - generic [ref=f1e270]:
                - strong [ref=f1e271]: "Reviewed library: Creator 5 Pro v1.0.0"
                - paragraph [ref=f1e272]: "Partial Pro coverage: only the exact-model user-guide 1000-hour shaft-cleaning requirement is activated. Other series-level maintenance articles and Pro repair videos remain references pending exact-variant procedure review. No standard Creator 5 schedule is copied."
              - button "Review Creator 5 Pro v1.0.0" [ref=f1e273] [cursor=pointer]
            - generic [ref=f1e274] [cursor=pointer]:
              - text: Import profile JSON
              - button "Import profile JSON" [ref=f1e279]
            - paragraph [ref=f1e280]: Packages contain data only. Imported verification claims remain pending unless they match an application-reviewed definition for the exact model, technology and version. Acknowledging a package does not grant manufacturer verification. Archived definitions are retained with their applied versions.
          - generic [ref=f1e281]:
            - generic [ref=f1e287]:
              - heading "Independent. Transparent. Local." [level=2] [ref=f1e288]
              - paragraph [ref=f1e289]: No app account or analytics integration in the reviewed application source. Hosting access systems are separate.
            - paragraph [ref=f1e290]: This app is an unofficial maintenance tracker. Use current manufacturer documentation when servicing your equipment.
            - button "Read the full disclaimer" [ref=f1e291] [cursor=pointer]
            - paragraph [ref=f1e292]: Acknowledgment version 1.0 · Jan 1, 2026
            - link "design@roseandpaw.ca" [ref=f1e293] [cursor=pointer]:
              - /url: mailto:design@roseandpaw.ca?subject=PrintGuard%203D%20-%20General%20Feedback
      - complementary "Manufacturer independence" [ref=f1e297]:
        - paragraph [ref=f1e298]: PrintGuard 3D is independent and unofficial; no printer manufacturer sponsors, endorses or supports this application. Manufacturer and model names identify equipment only. Brand names belong to their respective owners.
      - contentinfo [ref=f1e299]:
        - generic [ref=f1e300]: © 2026 PrintGuard 3D · Made for makers.
        - generic [ref=f1e301]:
          - button "Data handling information" [ref=f1e302] [cursor=pointer]
          - generic [ref=f1e303]: ·
          - button "Independent & unofficial" [ref=f1e304] [cursor=pointer]
          - generic [ref=f1e305]: ·
          - link "Feedback & support" [ref=f1e306] [cursor=pointer]:
            - /url: mailto:design@roseandpaw.ca?subject=PrintGuard%203D%20-%20General%20Feedback
          - generic [ref=f1e311]: Local storage
  - status [ref=f1e317]:
    - text: Browser notifications are not supported here.
    - button "Dismiss notification" [ref=f1e321] [cursor=pointer]
```

# Test source

```ts
  1  | import {createHash} from 'node:crypto';
  2  | import {test,expect} from '@playwright/test';
  3  | import AxeBuilder from '@axe-core/playwright';
  4  | import {seed,raw,fixture,tables,upload,replace,acknowledge,exportBackup,printerImage,origin} from './helpers.mjs';
  5  | 
  6  | const canonical=value=>Array.isArray(value)?value.map(canonical):value&&typeof value==='object'?Object.fromEntries(Object.keys(value).sort().map(key=>[key,canonical(value[key])])):value;
  7  | const fingerprints=rows=>Object.fromEntries([...rows].sort((a,b)=>a.id<b.id?-1:a.id>b.id?1:0).map(row=>[row.id,createHash('sha256').update(JSON.stringify(canonical(row))).digest('hex')]));
  8  | 
  9  | test('D01 real registration, exact-model profile update and guarded completion preserve independent history',async({page,context},info)=>{
  10 |  await seed(page,context);const before=await raw(page);await page.goto('/#My%20Printers');await page.getByRole('button',{name:'Add printer',exact:true}).click();let modal=page.getByRole('dialog');await modal.getByLabel('Printer name',{exact:true}).fill('Synthetic Phase5 C5');await modal.getByRole('combobox',{name:/^Model/}).selectOption('Creator 5');await modal.getByLabel('Current operating hours').fill('321');await modal.getByLabel('Completed prints',{exact:true}).fill('12');await modal.getByRole('combobox',{name:/^Maintenance profile version/}).selectOption('1.1.0');await modal.getByRole('button',{name:'Add printer & create schedule'}).click();await expect(page.getByRole('heading',{name:'Synthetic Phase5 C5',exact:true})).toBeVisible();
  11 |  let after=await raw(page);const created=after.printers.find(p=>p.name==='Synthetic Phase5 C5');expect(after.tasks.filter(t=>t.printerId===created.id)).toHaveLength(8);expect(after.logs).toEqual(before.logs);
  12 |  await page.goto('/#Settings');await page.getByRole('button',{name:'Review Creator 5 v1.1.0',exact:true}).click();modal=page.getByRole('dialog');await modal.getByRole('combobox',{name:/^Optional: apply/}).selectOption('p1');await modal.getByLabel(/I reviewed the changes and official documentation/).check();await modal.getByRole('button',{name:'Accept profile package'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);after=await raw(page);for(const t of before.tasks)expect(after.tasks).toContainEqual(t);expect(after.printers.find(p=>p.id==='p2')).toEqual(before.printers.find(p=>p.id==='p2'));expect(after.logs).toEqual(before.logs);
  13 |  await page.goto('/#Maintenance');await page.getByLabel('Filter by printer').selectOption('p1');await page.locator('button.task-row').filter({hasText:'Service positioning balls'}).click();await page.getByRole('button',{name:'Record maintenance',exact:true}).click();modal=page.getByRole('dialog');await expect(modal.getByRole('button',{name:'Save completed record'})).toBeDisabled();await modal.getByLabel(/I have reviewed the applicable instructions/).check();await expect(modal.getByRole('button',{name:'Save completed record'})).toBeDisabled();await modal.getByRole('checkbox',{name:/I have now reviewed/}).check();await modal.getByLabel('Work performed / reason skipped').fill('Synthetic Phase5 maintenance');await modal.getByRole('button',{name:'Save completed record'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);after=await raw(page);expect(after.logs).toHaveLength(before.logs.length+1);expect(after.logs.filter(l=>l.printerId==='p2')).toEqual(before.logs.filter(l=>l.printerId==='p2'));await info.attach('engine-version',{body:JSON.stringify({browser:page.context().browser().version(),newPrinterId:created.id,historyPreserved:true}),contentType:'application/json'});
  14 | });
  15 | 
  16 | test('D02 calendar through 2400, immutable history detail, mixed-currency reports and KPI drilldowns',async({page,context},info)=>{
  17 |  const data=await fixture();data.logs[0].currency='CAD';data.logs[1].currency='USD';data.logs[1].outcome='Skipped';await seed(page,context,data);const before=await raw(page);await page.goto('/#Calendar');for(const date of ['2035-01-01','2400-02-29','2500-03-01']){await page.getByLabel('Jump to calendar date').fill(date);await expect(page.locator('.calendar-cell')).toHaveCount(42);await expect(page.locator('.calendar-cell').filter({hasText:'NaN'})).toHaveCount(0);}
  18 |  await page.getByLabel('Jump to calendar date').fill(data.logs[0].date);await page.locator('button.calendar-event.complete').first().focus();await page.keyboard.press('Enter');await expect(page.getByRole('dialog')).toContainText('read only');await expect(page.getByRole('dialog').getByRole('button',{name:'Record maintenance'})).toHaveCount(0);await page.keyboard.press('Escape');await expect(page.locator('button.calendar-event.complete').first()).toBeFocused();
  19 |  await page.goto('/#Dashboard');await page.getByRole('button',{name:/Maintenance costs/}).click();await expect(page.getByRole('combobox',{name:'Report',exact:true})).toHaveValue('Maintenance Expenses');await expect(page.locator('.report-stats')).toContainText('12.50 CAD');await expect(page.locator('.report-stats')).toContainText('4.00 USD');await expect(page.locator('.report-stats')).toContainText('35.90 Unclassified currency');await page.getByRole('combobox',{name:'Report',exact:true}).selectOption('Complete Maintenance History');await page.getByRole('combobox',{name:'Category',exact:true}).selectOption('Lubrication');await expect(page.locator('.unclassified-history')).toContainText('Service positioning balls');expect(await raw(page)).toEqual(before);await info.attach('preservation',{body:JSON.stringify({allStoresUnchanged:true,calendarYears:[2035,2400,2500]}),contentType:'application/json'});
  20 | });
  21 | 
  22 | test('D03 real backup download, cancel, malformed/conflict rejection, idempotent merge and confirmed replacement',async({page,context},info)=>{
  23 |  await seed(page,context);await page.goto('/#Settings');const exported=await exportBackup(page,info);const before=await raw(page);await upload(page,exported);await expect(page.getByRole('heading',{name:'Review your backup'})).toBeVisible();await page.getByRole('button',{name:'Cancel',exact:true}).click();expect(await raw(page)).toEqual(before);await upload(page,'{broken');await expect(page.getByRole('alert')).toBeVisible();expect(await raw(page)).toEqual(before);
  24 |  const conflict=structuredClone(exported);conflict.printers[0].serial='SYNTHETIC CONFLICT';await upload(page,conflict);await expect(page.getByRole('dialog')).toContainText('Import blocked');await page.getByLabel(/I reviewed this import and confirm/).check();await expect(page.getByRole('button',{name:'Restore and merge'})).toBeDisabled();await page.getByRole('button',{name:'Cancel',exact:true}).click();expect(await raw(page)).toEqual(before);
  25 |  await upload(page,exported);await page.getByLabel(/I reviewed this import and confirm/).check();await expect(page.getByRole('button',{name:'Restore and merge'})).toBeEnabled();await page.getByRole('button',{name:'Restore and merge'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);expect(await raw(page)).toEqual(before);
  26 |  await replace(page,exported);let after=await raw(page);for(const key of tables)expect(after[key]).toEqual(exported[key]);expect(after.preferences[0].acknowledgment).toBeNull();await expect(page.locator('body')).not.toContainText('Review printer p1');await acknowledge(page);await page.reload();after=await raw(page);for(const key of tables)expect(after[key]).toEqual(exported[key]);
  27 | });
  28 | 
  29 | test('D04 large image-rich multi-printer backup restores every store and re-exports exactly',async({page,context},info)=>{
  30 |  test.setTimeout(240000);await seed(page,context);await page.goto('/#Settings');const source=await fixture(),image=await printerImage(page);const large={...source,printers:[],tasks:[],logs:[],readings:[],inventory:[],repairs:[]};
  31 |  for(let n=0;n<12;n++){const id='large-'+n,t='large-task-'+n;large.printers.push({...source.printers[0],id,name:'Synthetic large printer '+n,hours:600,prints:1000,image});large.tasks.push({...source.tasks[0],id:t,printerId:id,anchorDate:'2026-10-27',anchorHours:600,anchorPrints:1000});for(let k=0;k<50;k++)large.logs.push({...source.logs[0],id:'large-log-'+n+'-'+k,printerId:id,taskId:t,date:new Date(Date.UTC(2026,2,1+k)).toISOString().slice(0,10),hours:100+k,prints:10+k,image:'',currency:n%2?'CAD':'USD'});large.readings.push({id:'large-reading-'+n,printerId:id,date:'2026-10-27',hours:600,prints:1000});large.inventory.push({...source.inventory[0],id:'large-inventory-'+n,printerId:id});large.repairs.push({...source.repairs[0],id:'large-repair-'+n,printerId:id,image:'',currency:'CAD'});}
  32 |  large.profiles=large.profiles.map(p=>p.id==='custom-resin'?{...p,legacyMetadata:{nested:['preserve',1,true,null],note:'Synthetic unknown metadata'}}:p);const bytes=Buffer.byteLength(JSON.stringify(large));expect(bytes).toBeGreaterThan(20000000);expect(bytes).toBeLessThan(100000000);const start=Date.now();await replace(page,large);const restoreMs=Date.now()-start;const restored=await raw(page);for(const key of tables)expect(fingerprints(restored[key]),key+' native restore exact fields').toEqual(fingerprints(large[key]));await acknowledge(page);await page.goto('/#Settings');const exportStart=Date.now();const roundtrip=await exportBackup(page,info,'large-roundtrip.json');const exportMs=Date.now()-exportStart;for(const key of tables)expect(fingerprints(roundtrip[key]),key+' downloaded export exact fields').toEqual(fingerprints(large[key]));const metrics=await page.evaluate(async()=>({storage:await navigator.storage?.estimate(),heap:performance.memory?{used:performance.memory.usedJSHeapSize,limit:performance.memory.jsHeapSizeLimit}:null}));await info.attach('large-backup-metrics',{body:JSON.stringify({bytes,restoreMs,exportMs,browser:context.browser().version(),counts:Object.fromEntries(tables.map(k=>[k,large[k].length])),...metrics}),contentType:'application/json'});
  33 | });
  34 | 
  35 | test('D05 offline reopen and local source headers protect unchanged synthetic records',async({page,context,request},info)=>{
  36 |  await seed(page,context);const response=await page.goto('/#Dashboard');const headers=response.headers();expect(headers['content-security-policy']).toContain("frame-ancestors 'none'");expect(headers['referrer-policy']).toBe('strict-origin-when-cross-origin');expect(headers['permissions-policy']).toContain('camera=()');expect(headers['x-content-type-options']).toBe('nosniff');const before=await raw(page);
  37 |  await page.evaluate(async()=>{await navigator.serviceWorker.ready;await new Promise(resolve=>{if(navigator.serviceWorker.controller)resolve();else navigator.serviceWorker.addEventListener('controllerchange',resolve,{once:true});});});await context.unrouteAll({behavior:'wait'});await request.post(origin+'/__synthetic-network/off');try{let networkFailed=false;try{await request.get(origin+'/index.html',{timeout:3000});}catch{networkFailed=true;}expect(networkFailed).toBe(true);await page.close();const reopened=await context.newPage();await reopened.goto('/#Calendar');await expect(reopened.getByRole('heading',{name:'Calendar',exact:true})).toBeVisible();await reopened.getByLabel('Jump to calendar date').fill('2400-02-29');await expect(reopened.locator('.calendar-cell')).toHaveCount(42);await reopened.goto('/#Reports');await reopened.getByRole('combobox',{name:'Report',exact:true}).selectOption('Complete Maintenance Schedule');await expect(reopened.getByRole('cell',{name:'Service positioning balls & needle rollers',exact:true})).toHaveCount(2);expect(await raw(reopened)).toEqual(before);await info.attach('offline-local-security',{body:JSON.stringify({headers,browser:context.browser().version(),offlineReopen:true,productionVerified:false,originTransportDisabled:true,offlineEmulationUsed:false}),contentType:'application/json'});}finally{await request.post(origin+'/__synthetic-network/on');}
  38 | });
  39 | 
  40 | test('D06 keyboard focus, responsive layouts, both-theme axe scans and incomplete-node measurements',async({page,context},info)=>{
  41 |  test.setTimeout(240000);await seed(page,context);const audits=[];
  42 |  for(const theme of ['Light','Dark']){await page.goto('/#Settings');await page.getByRole('button',{name:theme,exact:true}).click();await expect(page.locator('html')).toHaveAttribute('data-theme',theme.toLowerCase());const immediateContrast=await page.locator('.sidebar .nav-item').evaluateAll(items=>{const rgb=value=>value.match(/[\d.]+/g).slice(0,3).map(Number);const lum=colour=>rgb(colour).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;}).reduce((sum,v,i)=>sum+v*[.2126,.7152,.0722][i],0);return items.map(item=>{const label=item.querySelector('span')||item,foreground=getComputedStyle(label).color;let parent=label,background;while(parent){background=getComputedStyle(parent).backgroundColor;if(background!=='transparent'&&!background.startsWith('rgba'))break;parent=parent.parentElement;}const a=lum(foreground),b=lum(background);return {label:label.textContent,foreground,background,ratio:(Math.max(a,b)+.05)/(Math.min(a,b)+.05)};});});await info.attach('immediate-theme-'+theme,{body:JSON.stringify(immediateContrast),contentType:'application/json'});for(const pair of immediateContrast)expect(pair.ratio,theme+' immediate '+pair.label).toBeGreaterThanOrEqual(4.5);for(const route of ['Dashboard','Reports','Calendar','Help%20%26%20Documentation']){await page.goto('/#'+route);await page.evaluate(()=>Promise.all(document.getAnimations().filter(animation=>animation.effect?.getTiming().iterations!==Infinity).map(animation=>animation.finished.catch(()=>{}))));const audit=await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa','wcag22aa']).analyze();audits.push({theme,route,violations:audit.violations,incomplete:audit.incomplete});if(audit.violations.length)await info.attach('failed-axe-'+theme+'-'+route,{body:JSON.stringify({theme,route,violations:audit.violations,incomplete:audit.incomplete}),contentType:'application/json'});expect(audit.violations.map(v=>({id:v.id,nodes:v.nodes.map(n=>n.target)}))).toEqual([]);}}
  43 |  await page.setViewportSize({width:320,height:900});await page.goto('/#Dashboard');expect(await page.evaluate(()=>document.documentElement.scrollWidth)).toBeLessThanOrEqual(320);await page.getByRole('button',{name:'Open navigation',exact:true}).focus();await page.keyboard.press('Enter');await expect(page.getByRole('dialog',{name:'Workshop navigation'})).toBeVisible();await page.keyboard.press('Escape');await expect(page.getByRole('button',{name:'Open navigation',exact:true})).toBeFocused();await page.emulateMedia({forcedColors:'active'});await expect(page.getByRole('button',{name:'Open navigation',exact:true})).toBeVisible();await page.screenshot({path:info.outputPath('forced-colors-320.png'),fullPage:true});await info.attach('axe-and-incomplete',{body:JSON.stringify(audits),contentType:'application/json'});
  44 | });
  45 | 
  46 | for(const state of ['granted','denied','unsupported'])test('D07 notification permission '+state+' keeps truthful app-open behavior',async({page,context},info)=>{
> 47 |  await context.addInitScript(state=>{window.syntheticNotifications=[];if(state==='unsupported'){delete window.Notification;return;}window.Notification=class{static permission=state;static async requestPermission(){return state;}constructor(title,options){window.syntheticNotifications.push({title,options});}};},state);await seed(page,context);await page.goto('/#Settings');await page.getByRole('button',{name:'Enable notifications',exact:true}).click();if(state==='granted'){await expect(page.getByRole('button',{name:'Disable notifications'})).toBeVisible();await expect.poll(()=>page.evaluate(()=>window.syntheticNotifications.length)).toBeGreaterThan(0);}else {await expect(page.getByRole('status')).toContainText(state==='denied'?'Permission was not granted':'not supported');expect((await raw(page)).preferences[0].notifications).toBe(false);expect(await page.evaluate(()=>window.syntheticNotifications)).toEqual([]);}await info.attach('permission-simulation',{body:JSON.stringify({state,simulatedAPI:true,nativeOSPromptNotVerified:true}),contentType:'application/json'});
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 ^ Error: expect(locator).toContainText(expected) failed
  48 | });
  49 | 
  50 | test('D09 native IndexedDB transaction abort during replacement preserves all stores and preferences',async({page,context},info)=>{
  51 |  await context.addInitScript(()=>{const add=IDBObjectStore.prototype.add;IDBObjectStore.prototype.add=function(...args){if(window.syntheticAbortRepair&&this.name==='repairs'){window.syntheticAbortRepair=false;this.transaction.abort();throw new DOMException('Synthetic quota failure during native replacement','QuotaExceededError');}return add.apply(this,args);};});
  52 |  await seed(page,context);await page.goto('/#Settings');const before=await raw(page),incoming=await fixture();incoming.printers[0].name='Synthetic replacement must roll back';await upload(page,incoming);await page.getByLabel('Replace all local records with this backup').check();await page.getByLabel(/I reviewed this import and confirm/).check();await expect(page.getByRole('button',{name:'Restore and replace'})).toBeEnabled();await page.evaluate(()=>{window.syntheticAbortRepair=true;});await page.getByRole('button',{name:'Restore and replace'}).click();await expect(page.getByRole('heading',{name:'That couldn’t be saved'})).toBeFocused();expect(await raw(page)).toEqual(before);await info.attach('native-abort',{body:JSON.stringify({allStoresAndPreferencesUnchanged:true,nativeTransactionAborted:true,quotaExceptionInjected:true,physicalQuotaNotExhausted:true}),contentType:'application/json'});
  53 | });
  54 | 
  55 | test('D10 first install requires consent, keeps Pro separate and records actual cumulative usage',async({page,context})=>{
  56 |  await context.route('**/*',route=>new URL(route.request().url()).origin===origin?route.continue():route.abort());await page.goto('/');await expect(page.getByRole('heading',{name:'Welcome to a better-kept workshop'})).toBeVisible();await page.getByRole('button',{name:'Review the disclaimer'}).click();await expect(page.getByRole('button',{name:/I Understand and Agree/})).toBeDisabled();await page.getByRole('checkbox').check();await page.getByRole('button',{name:/I Understand and Agree/}).click();let modal=page.getByRole('dialog');await modal.getByRole('combobox',{name:/^Model/}).selectOption('Creator 5 Pro');await modal.getByLabel('Printer name',{exact:true}).fill('Synthetic new-install Pro');await modal.getByRole('button',{name:'Add printer & create schedule'}).click();await expect(page.getByRole('dialog')).toHaveCount(0);await page.goto('/#My%20Printers');await page.getByRole('button',{name:'Synthetic new-install Pro',exact:true}).click();await page.getByRole('button',{name:'Log usage',exact:true}).click();modal=page.getByRole('dialog');await modal.getByLabel('Total operating hours').fill('1001');await modal.getByLabel('Total completed prints').fill('21');await modal.getByRole('button',{name:'Save reading'}).click();await expect(page.getByRole('heading',{name:'Record printer usage',exact:true})).toHaveCount(0);await page.getByRole('button',{name:'Close dialog'}).click();const records=await raw(page);expect(records.printers).toHaveLength(1);expect(records.printers[0].model).toBe('Creator 5 Pro');expect(records.printers[0].hours).toBe(1001);expect(Math.max(...records.readings.map(r=>r.hours))).toBe(1001);expect(records.tasks).toHaveLength(1);expect(records.tasks[0].interval.hours).toBe(1000);expect(records.logs).toEqual([]);await page.goto('/#Calendar');await expect(page.getByRole('region',{name:'Maintenance due from recorded usage'})).toContainText(records.tasks[0].title);
  57 | });
  58 | 
```